"""Offline Chromium verification of the authenticated OMEGA remote IDE frontend."""
from __future__ import annotations
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
HTML = ROOT / 'backend/omega_actions/ultimate/remote_ide.html'
OUT = ROOT / 'validation/ultimate'


def main():
    source = HTML.read_text(encoding='utf-8')
    bootstrap = '''<script>
    const mockFiles = {'src/main.py': 'print(42)'};
    window.fetch = async (url, options={}) => {
      const u=String(url), path=new URL('http://localhost'+u).searchParams.get('path');
      let result;
      if(u.startsWith('/api/tree')) result = {path:path||'.',entries:(path==='src'?
        [{name:'main.py',path:'src/main.py',directory:false,bytes:9}]:
        [{name:'src',path:'src',directory:true,bytes:null}])};
      else if(u.startsWith('/api/read')) result={path,content:mockFiles[path],sha256:'0'.repeat(64)};
      else if(u.startsWith('/api/write')) {
        const body=JSON.parse(options.body);mockFiles[body.path]=body.content;
        result={path:body.path,bytes:body.content.length,sha256:'1'.repeat(64)};
      }
      else return new Response('',{status:404});
      return new Response(JSON.stringify(result),{status:200,headers:{'Content-Type':'application/json'}});
    };
    </script>'''
    source = source.replace('<script>', bootstrap + '<script>', 1)
    errors=[]
    with sync_playwright() as playwright:
        browser=playwright.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        page=browser.new_page(viewport={'width':1440,'height':900},device_scale_factor=1)
        page.on('pageerror',lambda error: errors.append(str(error)))
        page.set_content(source,wait_until='load')
        page.locator('#file-tree button').first.wait_for(timeout=5000)
        page.get_by_role('button',name='src').click()
        page.get_by_role('button',name='main.py').click()
        page.wait_for_function("document.getElementById('editor').value === 'print(42)'", timeout=5000)
        page.locator('#editor').fill('print(43)')
        assert 'niezapisane' in page.locator('#dirty-indicator').inner_text()
        page.locator('#save-file').click()
        page.get_by_text('Zapisano',exact=False).wait_for(timeout=5000)
        assert not errors,errors
        OUT.mkdir(parents=True,exist_ok=True)
        page.screenshot(path=str(OUT/'remote_ide_desktop.png'),full_page=True)
        mobile=browser.new_page(viewport={'width':390,'height':844},device_scale_factor=1,is_mobile=True,has_touch=True)
        mobile.on('pageerror',lambda error:errors.append(str(error)))
        mobile.set_content(source,wait_until='load')
        mobile.locator('#file-tree button').first.wait_for(timeout=5000)
        mobile.screenshot(path=str(OUT/'remote_ide_mobile.png'),full_page=True)
        assert not errors,errors
        browser.close()
    report={'status':'PASS','checks':['file explorer','open file','edit','save','dirty state','mobile responsive','zero browser exceptions'],
            'backend_http':'verified separately by pytest','browser_fetch':'mocked (network sandbox)','page_errors':errors}
    (OUT/'remote_ide_browser_result.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
