"""Generate a source-grounded module reference for all Python backend modules."""
from __future__ import annotations
import ast
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]
BACKEND=ROOT/'backend'/'omega_actions'


def arguments(args):
    names=[arg.arg for arg in args.posonlyargs+args.args]
    if args.vararg:names.append('*'+args.vararg.arg)
    names.extend(arg.arg for arg in args.kwonlyargs)
    if args.kwarg:names.append('**'+args.kwarg.arg)
    return ', '.join(names)


def main():
    lines=['# Module Reference — wygenerowany z rzeczywistego kodu', '',
           'Poniższe sygnatury pochodzą bezpośrednio z parsera AST Python 3.13. ',
           'Nazwy metod są zgodne z plikami paczki; opis wiersza to pierwszy wiersz docstringu, jeśli istnieje.', '',
           '## Warstwa Python', '']
    files=sorted(BACKEND.rglob('*.py'))
    class_count=0
    func_count=0
    for path in files:
        if '__pycache__' in path.parts:continue
        source=path.read_text('utf-8')
        tree=ast.parse(source)
        rel=path.relative_to(ROOT).as_posix()
        lines.extend([f'### `{rel}`',''])
        summary=ast.get_docstring(tree)
        if summary:lines.append(summary.splitlines()[0]+'\n')
        found=0
        for node in tree.body:
            if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
                func_count+=1;found+=1
                prefix='async ' if isinstance(node,ast.AsyncFunctionDef) else ''
                signature=f'{prefix}{node.name}({arguments(node.args)})'
                description=(ast.get_docstring(node) or '').splitlines()
                lines.append(f'- `{signature}`'+(f' — {description[0]}' if description else ''))
            if isinstance(node,ast.ClassDef):
                class_count+=1;found+=1
                description=(ast.get_docstring(node) or '').splitlines()
                lines.append(f'- **class `{node.name}`**'+(f' — {description[0]}' if description else ''))
                for member in node.body:
                    if isinstance(member,(ast.FunctionDef,ast.AsyncFunctionDef)) and not member.name.startswith('__'):
                        func_count+=1
                        prefix='async ' if isinstance(member,ast.AsyncFunctionDef) else ''
                        signature=f'{prefix}{node.name}.{member.name}({arguments(member.args)})'
                        comment=(ast.get_docstring(member) or '').splitlines()
                        lines.append(f'  - `{signature}`'+(f' — {comment[0]}' if comment else ''))
        if not found:lines.append('- Moduł konfiguracji, danych lub rejestracji pakietu.')
        lines.append('')
    lines.extend(['## Android Java', '',
                  'Android sources reside in `android/app/src/main/java/org/omega/actions`. '
                  'The following class names are extracted from source files; compilation against Android SDK is a separate gate.', ''])
    java_files=sorted((ROOT/'android'/'app'/'src'/'main'/'java').rglob('*.java'))
    for file in java_files:
        data=file.read_text('utf-8')
        names=re.findall(r'\b(?:public|final|abstract)?\s*(?:class|interface|enum)\s+([A-Za-z_][A-Za-z0-9_]*)',data)
        lines.append(f'- `{file.relative_to(ROOT).as_posix()}` — {", ".join(names) or "Java source"}')
    lines.extend(['', '## Statystyki referencji', '',
                  f'- Pliki Python: **{len(files)}**.', f'- Klasy Python: **{class_count}**.',
                  f'- Funkcje/metody Python: **{func_count}**.',
                  f'- Pliki Java: **{len(java_files)}**.', '',
                  '## Kontrakty', '',
                  'Publiczne HTTP/JSON: `API_REFERENCE.md`. Bezpieczeństwo i zaufanie: `SECURITY_ARCHITECTURE.md`. '
                  'Wymagania binarne Android: `BUILD_AND_DEPLOYMENT_GUIDE.md`.'])
    target=ROOT/'MODULE_REFERENCE.md'
    target.write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print(f'{len(files)} Python files, {class_count} classes, {func_count} functions, {len(java_files)} Java files, {len(lines)} reference lines')


if __name__=='__main__':main()
