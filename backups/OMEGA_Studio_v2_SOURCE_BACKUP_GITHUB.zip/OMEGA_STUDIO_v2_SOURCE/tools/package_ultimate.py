"""Deterministic package with verified SHA-256 manifest and secure path inventory."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import re
import tempfile
import zipfile

ROOT=Path(__file__).resolve().parents[1]
OUT=Path('/mnt/data/OMEGA_STUDIO_ULTIMATE_SOURCE_SYNC_v1.1.0.zip')
PREFIX='OMEGA_STUDIO_ULTIMATE_v1.1.0/'
DOCS=('README.md','ARCHITECTURE.md','ENGINEERING_SPECIFICATION.md',
      'BEYOND_MAXIMUM_INNOVATIONS.md','MODULE_REFERENCE.md','API_REFERENCE.md',
      'SECURITY_ARCHITECTURE.md','BUILD_AND_DEPLOYMENT_GUIDE.md',
      'TESTING_AND_VALIDATION.md','DEPENDENCIES_AND_LICENSES.md',
      'DIGITAL_LIFE_COMPATIBILITY.md','INTEGRATION_BLUEPRINT.md',
      'PRODUCTION_READINESS_REPORT.md')
SKIP_DIRS={'.git','__pycache__','.pytest_cache','.venv','node_modules','.gradle','.mypy_cache'}
SOURCE_EXT={'.py','.java','.js','.mjs','.html','.css','.sh','.ps1','.kt','.ts','.tsx','.rs','.go','.c','.cpp'}
TEXT_EXT=SOURCE_EXT|{'.md','.json','.toml','.yml','.yaml','.xml','.gradle','.properties','.txt'}
FORBIDDEN=re.compile(r'\b(?:'+'|'.join(('TO'+'DO','FIX'+'ME','TB'+'D','Not'+'ImplementedError','unimplemented'+'!'))+r')\b')


def include(path: Path) -> bool:
    rel=path.relative_to(ROOT)
    if any(part in SKIP_DIRS for part in rel.parts):return False
    if rel.parts[:2]==('validation','ultimate') and len(rel.parts)>2 and rel.parts[2]=='browser_home':return False
    if rel.name in ('MANIFEST_SHA256.txt','package_validation.json') or rel.suffix in ('.pyc','.pyo'):
        return False
    if rel.name.endswith('.tmp') or rel.name.endswith('.part'):
        return False
    return True


def package() -> dict:
    missing=[name for name in DOCS if not (ROOT/name).is_file()]
    if missing:raise RuntimeError('Missing mandatory documents: '+str(missing))
    entries={}
    source_lines=0
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file() or not include(path):continue
        if path.is_symlink():raise RuntimeError('Symlink in package: '+str(path))
        rel=path.relative_to(ROOT).as_posix()
        if rel.startswith('/') or '..' in Path(rel).parts:raise RuntimeError('Unsafe package path')
        data=path.read_bytes()
        if path.suffix in TEXT_EXT:
            try:decoded=data.decode('utf-8')
            except UnicodeDecodeError:raise RuntimeError('Invalid UTF-8 text: '+rel)
            if FORBIDDEN.search(decoded):raise RuntimeError('Unfinished marker in '+rel)
        if path.suffix in SOURCE_EXT:
            source_lines+=len(data.splitlines())
        entries[rel]=data
    manifest=''.join(f'{hashlib.sha256(data).hexdigest()}  {path}\n' for path,data in sorted(entries.items()))
    entries['MANIFEST_SHA256.txt']=manifest.encode('utf-8')
    OUT.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(OUT,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7,allowZip64=True) as archive:
        for name,data in sorted(entries.items()):
            info=zipfile.ZipInfo(PREFIX+name,date_time=(2020,1,1,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=0o644<<16
            archive.writestr(info,data)
    with zipfile.ZipFile(OUT) as archive:
        if archive.testzip() is not None:raise RuntimeError('ZIP CRC failed')
        names=set(archive.namelist())
        if len(names)!=len(entries):raise RuntimeError('Duplicate ZIP paths')
        for line in archive.read(PREFIX+'MANIFEST_SHA256.txt').decode('utf-8').splitlines():
            digest,name=line.split('  ',1)
            if hashlib.sha256(archive.read(PREFIX+name)).hexdigest()!=digest:
                raise RuntimeError('Manifest mismatch: '+name)
        with tempfile.TemporaryDirectory(prefix='omega-unpack-') as tmp:
            archive.extractall(tmp)
            extracted=Path(tmp)/PREFIX.rstrip('/')
            if not (extracted/'README.md').is_file() or not (extracted/'backend/omega_actions/ultimate/crawler.py').is_file():
                raise RuntimeError('Extraction verification failed')
    report={'archive':OUT.name,'size_bytes':OUT.stat().st_size,'sha256':hashlib.sha256(OUT.read_bytes()).hexdigest(),
            'file_count':len(entries),'source_lines':source_lines,'sha256_manifest_entries':len(entries)-1,
            'zip_crc':'PASS','sha256_manifest':'PASS','unpack':'PASS',
            'mandatory_docs':len(DOCS),'unfinished_markers_in_project':'0',
            'android_production_apk':'NOT_BUILT','device_verified':False,
            'omega_studio_repository_updated':True,'digital_life_repository_modified':False}
    (OUT.parent/'OMEGA_STUDIO_ULTIMATE_SOURCE_SYNC_v1.1.0.validation.json').write_text(json.dumps(report,indent=2)+'\n')
    return report


if __name__=='__main__':print(json.dumps(package(),indent=2))
