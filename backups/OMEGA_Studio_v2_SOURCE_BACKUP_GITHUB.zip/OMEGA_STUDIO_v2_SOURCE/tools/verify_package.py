"""Validate ZIP integrity and each SHA-256 digest without extracting untrusted paths."""
from __future__ import annotations
import hashlib
from pathlib import Path, PurePosixPath
import stat
import sys
import zipfile


def verify(path: Path) -> dict:
    with zipfile.ZipFile(path) as archive:
        if archive.testzip() is not None:raise ValueError('ZIP CRC failed')
        infos=archive.infolist()
        if len({info.filename for info in infos})!=len(infos):raise ValueError('Duplicate archive member')
        for info in infos:
            parts=PurePosixPath(info.filename).parts
            if not parts or '..' in parts or info.filename.startswith('/') or '\\' in info.filename:
                raise ValueError('Unsafe archive member')
            mode=(info.external_attr>>16)&0o170000
            if mode not in (0,stat.S_IFREG,stat.S_IFDIR):raise ValueError('Special archive member')
        manifests=[name for name in archive.namelist() if name.endswith('/MANIFEST_SHA256.txt')]
        if len(manifests)!=1:raise ValueError('Expected exactly one manifest')
        prefix=manifests[0].removesuffix('MANIFEST_SHA256.txt')
        manifest=archive.read(manifests[0]).decode('utf-8')
        checks=0
        for line in manifest.splitlines():
            digest,name=line.split('  ',1)
            if hashlib.sha256(archive.read(prefix+name)).hexdigest()!=digest:
                raise ValueError('SHA-256 mismatch: '+name)
            checks+=1
        if checks+1!=len(infos):raise ValueError('Manifest does not cover all files')
        return {'status':'PASS','files':len(infos),'sha256_checked':checks,
                'archive_sha256':hashlib.sha256(path.read_bytes()).hexdigest()}


if __name__=='__main__':
    print(verify(Path(sys.argv[1])))
