"""Local reproducible microbenchmarks, never presented as competitive comparisons."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import statistics
import tempfile
import time
import httpx
from omega_actions.ultimate.archives import pack_zip, extract_zip
from omega_actions.ultimate.crawler import GitHubOrgCrawler
from omega_actions.ultimate.seal import seal_python_source
from omega_actions.ultimate.streamer import WindowedReader
from omega_actions.ultimate.swarm import SwarmCoordinator


def measure(fn, repetitions=5):
    samples=[]
    for _ in range(repetitions):
        t=time.perf_counter_ns()
        fn()
        samples.append((time.perf_counter_ns()-t)/1e6)
    return {'median_ms':round(statistics.median(samples),3),'min_ms':round(min(samples),3),
            'max_ms':round(max(samples),3),'repetitions':repetitions}


def main():
    with tempfile.TemporaryDirectory() as temp:
        root=Path(temp)
        path=root/'large.bin'
        with path.open('wb') as f:
            for _ in range(16):f.write(hashlib.sha256(b'OMEGA').digest()*65536)
        def stream():
            with WindowedReader(path,window_size=1024*1024) as reader:
                return reader.digest()
        sha=stream()
        stream_time=measure(stream,3)
        def swarm():
            with SwarmCoordinator(max_workers=4,max_pending=16) as pool:
                result=pool.map(lambda x:x*x,range(1000))
                assert sum(result)==332833500
        swarm_time=measure(swarm,3)
        source=root/'src';source.mkdir()
        for i in range(100): (source/f'{i:03}.txt').write_text(f'OMEGA {i}')
        archive=root/'benchmark.zip'
        zip_time=measure(lambda:pack_zip(source,archive),3)
        seal_time=measure(lambda:seal_python_source('def omega(x):\n return x*x\n',secret=b'benchmark-secret'),10)
        pages=[]
        def mock(req):
            pages.append(int(req.url.params['page']))
            return httpx.Response(200,json=[{'full_name':f'github/r-{req.url.params["page"]}','license':{'spdx_id':'MIT'}}])
        with httpx.Client(transport=httpx.MockTransport(mock)) as client:
            crawl_time=measure(lambda:GitHubOrgCrawler(client).crawl('github',pages=20),3)
        return {'scope':'HOST_MICROBENCHMARK_NO_COMPETITOR_BASELINE',
                'dataset_bytes':path.stat().st_size,'sha256':sha,'results':{
                    'mmap_sha256_32MiB':stream_time,'swarm_1000_tasks':swarm_time,
                    'zip_100_files':zip_time,'ast_seal':seal_time,'github_20_mock_pages':crawl_time},
                'notes':'Timing includes Python overhead and local filesystem; network crawler uses mocked HTTP.'}


if __name__=='__main__':
    result=main()
    out=Path(__file__).resolve().parents[1]/'validation'/'ultimate'/'benchmark.json'
    out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))
