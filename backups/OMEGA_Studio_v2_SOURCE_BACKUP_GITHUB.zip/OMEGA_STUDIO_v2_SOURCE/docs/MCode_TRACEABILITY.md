# Ślad wymagań MCode.pdf (11 stron)

| Strony PDF | Wymaganie | Odpowiedzialny kod | Stan |
|---|---|---|---|
| 1–4 | VS Code 1.85.1, IntelliSense, debug, multi-cursor, split screen, workspaces, terminal, port 8080 | Android `CodeServerManager`, `CodeEditorActivity`, backend CI, `remote8080.py` | Adaptery/edytor i remote workspace; brak binarnego VS Code 1.85.1 |
| 5 | Ponad 170 języków, NoCode, Chat Leak/Duo, dowolne pliki, ZIP/RAR, 2D–4D | AppBuilder, `ultimate/swarm.py`, `archives.py`, `assets.py`, `streamer.py` | Testowane podzbiory; brak 170 kompletnych language serverów |
| 6 | Własne Actions, GitHub/GitLab/HF/Drive, bounded mmap, AST, vault | `omega_actions/engine.py`, `ultimate/cloud.py`, `crawler.py`, `streamer.py`, `seal.py`, `vault.py` | Implementacja i testy hostowe |
| 7–9 | Kwantowy AST, holograficzna pamięć, samoreplikujące mikroserwisy, neuromorficzny rój | Konserwatywna implementacja AST/topology, mmap, bounded graph diffusion | Brak dowodu kwantowych/holograficznych twierdzeń; nieautoryzowana samoreplikacja wyłączona |
| 9–11 | GitHub organization pages 1–20 | `config/organization_sources.json`, `GitHubOrgCrawler` | 20 stron w deterministycznym mock API; live crawler wywoływany na żądanie |

Zasada: specyfikacja opisuje oczekiwania użytkownika. Tabela nie podnosi statusu modułu ponad faktycznie wykonany kod i testy. Testy symulacyjne nie są zamiennikiem urządzenia ani audytu.
