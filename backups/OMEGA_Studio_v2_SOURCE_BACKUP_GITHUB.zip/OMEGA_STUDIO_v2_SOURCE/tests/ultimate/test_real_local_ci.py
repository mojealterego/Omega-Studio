"""Real local native CI run, isolated from source repo and without GitHub-hosted Actions."""
import asyncio
from pathlib import Path
from omega_actions.config import Settings
from omega_actions.engine import Engine


def test_real_local_workflow_execution(tmp_path):
    repo=tmp_path/'repository';repo.mkdir()
    workflows=repo/'.github'/'workflows';workflows.mkdir(parents=True)
    (repo/'input.txt').write_text('OMEGA')
    workflow=workflows/'local.yml'
    workflow.write_text('''name: Omega Local E2E\non: workflow_dispatch\njobs:\n  compile:\n    runs-on: ubuntu-latest\n    steps:\n      - run: test -f input.txt\n      - run: printf 'verified\\n' > result.txt\n  verify:\n    needs: compile\n    runs-on: ubuntu-latest\n    steps:\n      - run: echo "local-ci-success"\n''')
    engine=Engine(Settings(home=tmp_path/'engine-home',unsafe_native=True,max_parallel=2))
    result=asyncio.run(engine.run(workflow,repo,engine='native'))
    assert result['status']=='success',result
    assert result['jobs']=={'compile':'success','verify':'success'}
    assert not (repo/'result.txt').exists()  # execution occurs in isolated workspace copy
    assert engine.store.run(result['id'])['status']=='success'
