import json
import os
from pathlib import Path
import subprocess
import sys
from omega_actions.ultimate.simulation import run_simulation


def test_simulation_deterministic_and_invariants():
    a=run_simulation(seed=20261110, jobs=64)
    b=run_simulation(seed=20261110, jobs=64)
    assert a==b
    assert all(a['invariants'].values())
    assert a['crawler']['pages']==20
    assert a['workflow']['jobs']==2
    assert a['gguf']['version']==3


def test_cli_end_to_end(tmp_path):
    env={**os.environ,'PYTHONPATH':str(Path(__file__).resolve().parents[2]/'backend')}
    src=tmp_path/'src';src.mkdir();(src/'hello.txt').write_text('omega')
    archive=tmp_path/'output.zip';dst=tmp_path/'dst'
    for args in [['zip-pack',str(src),str(archive)], ['zip-extract',str(archive),str(dst)],
                 ['asset','svg',str(tmp_path/'omega.svg'),'--text','Omega']]:
        proc=subprocess.run([sys.executable,'-m','omega_actions.ultimate',*args],env=env,capture_output=True,text=True,timeout=20)
        assert proc.returncode==0,proc.stderr
    assert (dst/'hello.txt').read_text()=='omega'
    assert '<svg' in (tmp_path/'omega.svg').read_text()
