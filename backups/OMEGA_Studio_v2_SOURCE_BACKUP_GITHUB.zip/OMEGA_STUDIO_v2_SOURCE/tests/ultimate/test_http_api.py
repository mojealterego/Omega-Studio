import base64
import hashlib
from pathlib import Path
import pytest
from fastapi.testclient import TestClient
from omega_actions.ultimate.remote8080 import create_remote_app, RemoteConfig, RemoteError
from omega_actions.ultimate.router import create_ultimate_router
from fastapi import FastAPI


def test_remote_config_refuses_insecure_lan():
    with pytest.raises(RemoteError):RemoteConfig(bind='0.0.0.0',port=8080,username='omega',password='secret-password')
    assert RemoteConfig(bind='127.0.0.1',port=8080,username='omega',password='secret-password').port==8080


def test_remote_http_auth_workspace_and_ws(tmp_path):
    (tmp_path/'hello.py').write_text('print(42)')
    app=create_remote_app(tmp_path,username='omega',password='long-secret-123')
    client=TestClient(app)
    assert client.get('/api/files').status_code==401
    token=base64.b64encode(b'omega:long-secret-123').decode()
    headers={'Authorization':'Basic '+token}
    assert client.get('/api/files',headers=headers).json()['files'][0]['name']=='hello.py'
    r=client.get('/api/read',params={'path':'hello.py'},headers=headers)
    assert r.status_code==200 and r.json()['content']=='print(42)'
    digest=r.json()['sha256']
    assert client.put('/api/write',headers=headers,json={'path':'hello.py','content':'print(43)','expected_sha256':digest}).status_code==200
    assert (tmp_path/'hello.py').read_text()=='print(43)'
    assert client.get('/api/read',params={'path':'../secret'},headers=headers).status_code==403
    assert client.put('/api/write',headers=headers,json={'path':'hello.py','content':'x','expected_sha256':digest}).status_code==409
    with client.websocket_connect('/ws',headers=headers) as ws:
        assert ws.receive_json()['type']=='hello'
        ws.send_json({'type':'ping'})
        assert ws.receive_json()['type']=='pong'


def test_ultimate_router_endpoints(tmp_path):
    app=FastAPI();app.include_router(create_ultimate_router(tmp_path))
    client=TestClient(app)
    assert client.get('/api/ultimate/status').json()['features']['repo_crawler']=='ready'
    svg=client.post('/api/ultimate/assets',json={'kind':'svg','text':'Test'});
    assert svg.status_code==200 and b'<svg' in svg.content
    result=client.post('/api/ultimate/nocode',json={'description':'Moja aplikacja do notatek'})
    assert result.status_code==200 and 'Moja aplikacja do notatek' in result.json()['html']


def test_remote_rejects_multibyte_payload_over_byte_limit(tmp_path):
    app=create_remote_app(tmp_path,username='omega',password='long-secret-123')
    client=TestClient(app)
    headers={'Authorization':'Basic '+base64.b64encode(b'omega:long-secret-123').decode()}
    result=client.put('/api/write',headers=headers,json={'path':'large.txt','content':'ą'*600_000})
    assert result.status_code==413
    assert not (tmp_path/'large.txt').exists()


def test_ultimate_swarm_endpoint(tmp_path):
    app=FastAPI();app.include_router(create_ultimate_router(tmp_path))
    client=TestClient(app)
    result=client.post('/api/ultimate/analyze',json={'mode':'leak','source':'eval("1+1")'}).json()
    assert result['syntax_valid']
    assert any(item['rule']=='unsafe_eval' for item in result['findings'])
