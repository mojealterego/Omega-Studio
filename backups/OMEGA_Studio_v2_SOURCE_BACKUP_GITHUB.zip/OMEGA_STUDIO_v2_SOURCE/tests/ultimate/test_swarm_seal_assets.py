import hashlib
import json
import wave
import pytest
from omega_actions.ultimate.swarm import LoadBalancer, SwarmCoordinator, DuoCoordinator, SwarmError
from omega_actions.ultimate.seal import graph_invariants, seal_python_source, verify_seal
from omega_actions.ultimate.assets import make_svg, make_png, make_wav, make_gltf_animation


def test_load_balancer_conserves_work_and_bounds():
    b=LoadBalancer([1,2,3,4],links=[(0,1),(1,2),(2,3)])
    new=b.diffuse([10.,0.,0.,0.],rate=0.2,steps=5)
    assert sum(new)==pytest.approx(10)
    assert min(new)>=0 and max(new)<10


def test_swarm_parallel_results_and_bound():
    with SwarmCoordinator(max_workers=3,max_pending=6) as swarm:
        result=swarm.map(lambda x:x*x,range(15))
        assert result==[i*i for i in range(15)]
        assert swarm.peak_active<=3


def test_duo_bounded_verification():
    duo=DuoCoordinator(max_rounds=3)
    assert duo.run(lambda text,attempt:f'{text}:{attempt}',lambda out:out.endswith(':2'),'hello')=='hello:2'
    with pytest.raises(SwarmError):DuoCoordinator(max_rounds=2).run(lambda x,i:'invalid',lambda x:False,'hello')


def test_seal_detects_ast_tampering():
    seal=seal_python_source('def f(x):\n return x+1\n',secret=b'secure-key')
    assert verify_seal('def f(x):\n return x+1\n',seal,secret=b'secure-key')
    assert not verify_seal('def f(x):\n return x+2\n',seal,secret=b'secure-key')
    assert seal['beta1']==0


def test_graph_invariants_for_cycle_and_forest():
    g=graph_invariants(4,[(0,1),(1,2),(2,0)])
    assert g['components']==2 and g['beta1']==1 and g['euler_characteristic']==1
    with pytest.raises(ValueError):graph_invariants(2,[(0,2)])


def test_svg_png_wav_and_animated_gltf(tmp_path):
    svg=make_svg('Omega & <Studio>',size=256)
    assert '&lt;Studio&gt;' in svg and '<script' not in svg
    png=make_png(32,16,(14,16,21))
    assert png[:8]==b'\x89PNG\r\n\x1a\n'
    wav=make_wav(440,0.15)
    target=tmp_path/'x.wav';target.write_bytes(wav)
    with wave.open(str(target)) as f:
        assert f.getnframes()>100 and f.getframerate()==22050
    gltf=make_gltf_animation(duration=2.0)
    assert gltf['asset']['version']=='2.0'
    assert gltf['animations'][0]['channels']
    assert gltf['buffers'][0]['uri'].startswith('data:application/octet-stream;base64,')


def test_procedural_mp4_video(tmp_path):
    import shutil
    import subprocess
    from omega_actions.ultimate.assets import make_video
    if not shutil.which('ffmpeg') or not shutil.which('ffprobe'):
        pytest.skip('ffmpeg and ffprobe are optional native executables')
    target=tmp_path/'omega.mp4'
    report=make_video(target,duration=0.5,fps=10,width=160,height=96)
    assert report['bytes']>1000
    meta=subprocess.run(['ffprobe','-v','error','-show_entries','format=format_name',
                         '-of','default=noprint_wrappers=1',str(target)],capture_output=True,text=True,check=True)
    assert 'mp4' in meta.stdout
