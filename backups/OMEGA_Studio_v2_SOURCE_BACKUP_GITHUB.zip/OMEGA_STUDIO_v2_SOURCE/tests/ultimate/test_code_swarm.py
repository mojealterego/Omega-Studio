from omega_actions.ultimate.code_swarm import analyze_source


def test_swarm_static_analysis_detects_risky_patterns():
    source='''import os\nAPI_KEY = "sk-test-12345678901234567890"\ndef run(text):\n    eval(text)\n    os.system(text)\n'''
    result=analyze_source(source,mode='leak')
    assert result['syntax_valid']
    assert result['analyzers']==4
    assert {'unsafe_eval','shell_execution','hardcoded_secret'} <= {x['rule'] for x in result['findings']}


def test_duo_verification_and_syntax_failure():
    valid=analyze_source('def f(x):\n return x + 1\n',mode='duo')
    assert valid['syntax_valid'] and valid['verified']
    invalid=analyze_source('def f(:\n pass',mode='duo')
    assert not invalid['syntax_valid'] and not invalid['verified']
