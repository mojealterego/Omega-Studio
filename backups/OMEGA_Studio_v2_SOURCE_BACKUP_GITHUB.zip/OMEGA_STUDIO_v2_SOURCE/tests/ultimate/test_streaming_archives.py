import hashlib
import io
import os
from pathlib import Path
import stat
import zipfile
import pytest
from omega_actions.ultimate.streamer import WindowedReader, copy_file
from omega_actions.ultimate.archives import ArchiveError, pack_zip, extract_zip, pack_rar


def test_windowed_reader_random_access_and_sha256(tmp_path):
    data = bytes(range(256)) * 4096
    path = tmp_path/'sample.bin'; path.write_bytes(data)
    with WindowedReader(path, window_size=4096) as reader:
        assert reader.read_at(3, 19) == data[3:22]
        assert reader.read_at(len(data)-10, 100) == data[-10:]
        assert reader.read_at(len(data), 1) == b''
        assert reader.digest() == hashlib.sha256(data).hexdigest()
        assert max(len(part) for part in reader.iter_chunks()) <= 4096
        with pytest.raises(ValueError): reader.read_at(-1, 10)
        with pytest.raises(ValueError): reader.read_at(0, 4097)


def test_windowed_reader_sparse_file_over_four_gib(tmp_path):
    path = tmp_path/'sparse.bin'
    with path.open('wb') as f:
        f.seek(5*1024**3)
        f.write(b'OMEGA')
    with WindowedReader(path, window_size=8192) as reader:
        assert reader.size > 2**32
        assert reader.read_at(reader.size-5, 5) == b'OMEGA'
        assert reader.read_at(0, 16) == bytes(16)


def test_copy_file_streamed(tmp_path):
    src = tmp_path/'a'; dst=tmp_path/'b'; src.write_bytes(os.urandom(32769))
    result = copy_file(src,dst,chunk_size=1024)
    assert result['sha256'] == hashlib.sha256(src.read_bytes()).hexdigest()
    assert dst.read_bytes()==src.read_bytes()


def test_deterministic_zip_and_extract(tmp_path):
    src=tmp_path/'src'; src.mkdir(); (src/'b.txt').write_text('b'); (src/'a.txt').write_text('a')
    (src/'dir').mkdir(); (src/'dir'/'z').write_bytes(b'z')
    a=tmp_path/'a.zip'; b=tmp_path/'b.zip'
    pack_zip(src,a); pack_zip(src,b)
    assert a.read_bytes()==b.read_bytes()
    target=tmp_path/'unpacked'; report=extract_zip(a,target)
    assert report['files']==3
    assert (target/'dir'/'z').read_bytes()==b'z'


@pytest.mark.parametrize('member', ['../escape','/absolute','nested/../../escape','C:/drive'])
def test_zip_traversal_rejected(tmp_path,member):
    arc=tmp_path/'evil.zip'
    with zipfile.ZipFile(arc,'w') as z:z.writestr(member,b'bad')
    with pytest.raises(ArchiveError):extract_zip(arc,tmp_path/'target')
    assert not (tmp_path/'escape').exists()


def test_zip_symlink_rejected(tmp_path):
    arc=tmp_path/'evil.zip'; info=zipfile.ZipInfo('symlink')
    info.create_system=3; info.external_attr=(stat.S_IFLNK|0o777)<<16
    with zipfile.ZipFile(arc,'w') as z:z.writestr(info,'/etc/passwd')
    with pytest.raises(ArchiveError):extract_zip(arc,tmp_path/'target')


def test_zip_quota_rejected(tmp_path):
    arc=tmp_path/'big.zip'
    with zipfile.ZipFile(arc,'w',zipfile.ZIP_DEFLATED) as z:z.writestr('a',b'a'*5000)
    with pytest.raises(ArchiveError):extract_zip(arc,tmp_path/'target',max_total_bytes=100)


def test_rar_writer_fails_closed_without_binary(tmp_path,monkeypatch):
    monkeypatch.setattr('shutil.which',lambda _:None)
    with pytest.raises(ArchiveError,match='RAR'):
        pack_rar(tmp_path,tmp_path/'x.rar')


def test_rar_extraction_requires_supported_archive(tmp_path):
    from omega_actions.ultimate.archives import extract_rar
    bogus=tmp_path/'bogus.rar';bogus.write_bytes(b'not a rar')
    with pytest.raises(ArchiveError):extract_rar(bogus,tmp_path/'out')
    assert not (tmp_path/'out').exists()
