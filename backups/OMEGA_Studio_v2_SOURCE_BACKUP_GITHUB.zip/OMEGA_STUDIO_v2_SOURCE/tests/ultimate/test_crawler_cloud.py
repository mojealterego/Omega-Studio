import io
import json
from pathlib import Path
import zipfile
import httpx
import pytest
from omega_actions.ultimate.crawler import GitHubOrgCrawler, RepositoryIndex, CrawlerError
from omega_actions.ultimate.cloud import MultiCloudHub


def test_github_crawl_twenty_pages_dedup_and_index(tmp_path):
    seen=[]
    def handler(req):
        assert req.url.host=='api.github.com'
        assert req.url.path=='/orgs/github/repos'
        page=int(req.url.params['page']);seen.append(page)
        return httpx.Response(200,json=[{'id':page,'full_name':f'github/repo-{page}', 'description':'repository',
                                        'default_branch':'main','html_url':f'https://github.com/github/repo-{page}',
                                        'license':{'spdx_id':'MIT'},'language':'Python','size':1}])
    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        crawler=GitHubOrgCrawler(client)
        items=crawler.crawl('github',pages=20)
    assert seen==list(range(1,21)) and len(items)==20
    with RepositoryIndex(tmp_path/'index.db') as index:
        assert index.upsert(items)==20
        assert len(index.search('repo-'))==20
        assert index.count()==20


def test_crawler_rejects_invalid_org():
    with pytest.raises(ValueError):GitHubOrgCrawler().crawl('../private',pages=20)


def test_crawler_rate_limit_error():
    with httpx.Client(transport=httpx.MockTransport(lambda req:httpx.Response(403,headers={'x-ratelimit-remaining':'0'},json={'message':'rate limit'}))) as client:
        with pytest.raises(CrawlerError,match='rate limit'):
            GitHubOrgCrawler(client).crawl('github',pages=1)


def test_crawler_rejects_untrusted_fields():
    with httpx.Client(transport=httpx.MockTransport(lambda req:httpx.Response(200,json=[{'full_name':'../etc/passwd'}]))) as client:
        with pytest.raises(CrawlerError):GitHubOrgCrawler(client).crawl('github',pages=1)


def test_crawler_snapshot_safe_local_only(tmp_path):
    b=io.BytesIO()
    with zipfile.ZipFile(b,'w') as z:z.writestr('repo-main/README.md','safe')
    def handler(req):
        assert req.url.host=='codeload.github.com'
        return httpx.Response(200,content=b.getvalue())
    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        result=GitHubOrgCrawler(client).download_snapshot('github','repo','a'*40,tmp_path/'workspace')
    assert result['files']==1
    assert (tmp_path/'workspace'/'repo-main'/'README.md').read_text()=='safe'


def test_cloud_providers_http_contract():
    calls=[]
    def handler(req):
        calls.append((req.url.host,req.url.path))
        if req.url.host=='gitlab.com':return httpx.Response(200,json=[{'id':1,'name':'project'}])
        if req.url.host=='huggingface.co':return httpx.Response(200,json=[{'id':'repo/model'}])
        if req.url.host=='www.googleapis.com':return httpx.Response(200,json={'files':[{'id':'a','name':'doc'}],'nextPageToken':None})
        return httpx.Response(404)
    with httpx.Client(transport=httpx.MockTransport(handler)) as client:
        hub=MultiCloudHub(client)
        assert hub.gitlab_projects(page=1)[0]['id']==1
        assert hub.hf_models(limit=10)[0]['id']=='repo/model'
        assert hub.drive_files('token')['files'][0]['id']=='a'
    assert {host for host,_ in calls}=={'gitlab.com','huggingface.co','www.googleapis.com'}


def test_cloud_rejects_invalid_page_and_drive_token():
    hub=MultiCloudHub()
    with pytest.raises(ValueError):hub.gitlab_projects(page=0)
    with pytest.raises(ValueError):hub.drive_files('')
